use(function () {

  var breadcrumbs = new Array();
  var bcStart = properties.get('bcStart');
  var currentDepth = currentPage.getDepth();  
  for(var i=1;i<=bcStart;i++){ 
      var title = '';
      var bcHideCurrent = false;
      var hideInNav = false;
      var thisPage = currentPage.getAbsoluteParent(i);

      if(thisPage !== null){
        hideInNav = thisPage.isHideInNav();
        if(i == currentDepth - 1){ 
          bcHideCurrent = properties.get('bcHideCurrent');
        }
        if(hideInNav || bcHideCurrent){
          continue;
        }

        title = thisPage.getNavigationTitle();
        if (title == undefined || title == "") {
          title = thisPage.getTitle();
          if (title == undefined || title == "") {
            title = thisPage.getName();
          }
        } 

      var path = thisPage.getPath();
      var page = {
        title : title,
        path : path,
        hideInNav : hideInNav,
        bcHideCurrent : bcHideCurrent
      }

      breadcrumbs.push(page);

    }
  }
    return {
      breadcrumbs : breadcrumbs,
      };
    });